package org.telegram.telegrambots.generics;

/**
 * @author Ruben Bermudez
 * @version 1.0
 * Bot options
 */
public interface BotOptions {
    String getBaseUrl();
}
