package org.telegram.telegrambots.generics;

/**
 * @author Ruben Bermudez
 * @version 1.0
 * Base Updates Handler interface
 */
public interface UpdatesHandler {
}
