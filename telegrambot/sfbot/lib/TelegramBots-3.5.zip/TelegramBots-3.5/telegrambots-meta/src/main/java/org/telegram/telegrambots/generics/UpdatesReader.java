package org.telegram.telegrambots.generics;

/**
 * @author Ruben Bermudez
 * @version 1.0
 * Updates reader interface
 */
public interface UpdatesReader {
    void start();
}
