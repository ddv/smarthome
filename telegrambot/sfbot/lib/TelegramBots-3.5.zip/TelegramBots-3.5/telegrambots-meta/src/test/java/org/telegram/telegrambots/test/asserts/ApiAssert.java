package org.telegram.telegrambots.test.asserts;

/**
 * @author Ruben Bermudez
 * @version 1.0
 */
public final class ApiAssert {
    private ApiAssert() {}
}
