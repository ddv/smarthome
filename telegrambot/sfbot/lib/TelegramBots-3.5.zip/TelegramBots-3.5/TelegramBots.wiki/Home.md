Welcome to the TelegramBots wiki. Use the sidebar on the right. If you're not sure what to look at, why not take a look at the [[Getting Started|Getting-Started]] guide?

If you want more detailed explanations, you can also visit this [gitbook by MonsterDeveloper's](https://www.gitbook.com/book/monsterdeveloper/writing-telegram-bots-on-java/details)